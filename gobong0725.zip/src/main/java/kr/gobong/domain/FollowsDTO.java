package kr.gobong.domain;

import lombok.Data;

@Data
public class FollowsDTO {

	private String id;
	private String following_id;
}
