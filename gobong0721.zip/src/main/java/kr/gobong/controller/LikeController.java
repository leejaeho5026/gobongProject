package kr.gobong.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.gobong.domain.LikeDTO;
import kr.gobong.domain.UserDTO;
import kr.gobong.service.LikeService;

@Controller
@RequestMapping("/like")
public class LikeController {
	
	@Autowired
	LikeService likeService;
	
	@Resource(name = "loginUser")
	@Lazy
	private UserDTO loginUser;
	
	
	
	@GetMapping("/upLike.do")
	public void upLike(@RequestParam("no") int no,LikeDTO likeDto) {
		likeService.upLike(no);
		likeDto.setNo(no);
		likeService.registLike(likeDto);
		
	}
	
	@GetMapping("/disLike.do")
	public void disLike(@RequestParam("no") int no,LikeDTO likeDto) {
		likeService.disLike(no);
		
	}
	
	
	//펑션 안넣고 c:if 좋아요 0보다 클경우 스크립트시작으로 하면될듯
	@GetMapping("/likeList.do")
	public List<LikeDTO> likeList(@RequestParam("no") int no){
		List<LikeDTO> likeList = likeService.likeListInBoard(no);
		return likeList;
	}

	
	
	
}
